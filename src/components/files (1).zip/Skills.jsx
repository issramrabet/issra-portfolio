import { useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { skills } from '../data/projects';

const categoryColors = {
  'AI & Data': { color: '#8b5cf6', glow: 'rgba(139,92,246,0.2)' },
  'Languages': { color: '#06b6d4', glow: 'rgba(6,182,212,0.2)' },
  'Web & Deploy': { color: '#ec4899', glow: 'rgba(236,72,153,0.2)' },
  'Tools': { color: '#f59e0b', glow: 'rgba(245,158,11,0.2)' },
};

export default function Skills() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting) {
            e.target.querySelectorAll('.reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 100);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="skills"
      ref={sectionRef}
      style={{ padding: 'clamp(80px, 10vw, 140px) clamp(24px, 5vw, 80px)' }}
    >
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        {/* Label */}
        <div className="reveal" style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', letterSpacing: '0.3em', color: 'var(--violet)', textTransform: 'uppercase' }}>
            02. Skills
          </span>
          <div style={{ flex: 1, height: 1, background: 'var(--border)', maxWidth: 80 }} />
        </div>

        <h2 className="reveal" style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(42px, 6vw, 72px)',
          lineHeight: 0.95,
          letterSpacing: '-0.01em',
          marginBottom: 64,
        }}>
          The <span className="gradient-text">Arsenal</span>
        </h2>

        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(260px, 1fr))',
          gap: 24,
        }}>
          {Object.entries(skills).map(([category, items]) => {
            const { color, glow } = categoryColors[category];
            return (
              <div
                key={category}
                className="reveal"
                style={{
                  padding: '28px',
                  background: 'var(--surface)',
                  border: '1px solid var(--border)',
                  borderRadius: 16,
                  transition: 'border-color 0.3s ease, transform 0.3s ease',
                }}
                onMouseEnter={e => { e.currentTarget.style.borderColor = color; e.currentTarget.style.transform = 'translateY(-4px)'; }}
                onMouseLeave={e => { e.currentTarget.style.borderColor = 'var(--border)'; e.currentTarget.style.transform = 'translateY(0)'; }}
              >
                <div style={{
                  width: 8,
                  height: 8,
                  borderRadius: '50%',
                  background: color,
                  boxShadow: `0 0 12px ${glow}`,
                  marginBottom: 16,
                }} />
                <div style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.7rem',
                  letterSpacing: '0.2em',
                  color,
                  textTransform: 'uppercase',
                  marginBottom: 20,
                }}>
                  {category}
                </div>
                <div style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
                  {items.map((item, i) => (
                    <motion.span
                      key={item}
                      initial={{ opacity: 0, scale: 0.8 }}
                      whileInView={{ opacity: 1, scale: 1 }}
                      viewport={{ once: true }}
                      transition={{ delay: i * 0.05, duration: 0.3 }}
                      style={{
                        padding: '5px 12px',
                        borderRadius: 100,
                        background: glow,
                        border: `1px solid ${color}30`,
                        color: color,
                        fontFamily: 'var(--font-mono)',
                        fontSize: '0.73rem',
                        cursor: 'default',
                        transition: 'all 0.2s',
                      }}
                      whileHover={{ scale: 1.08, boxShadow: `0 0 15px ${glow}` }}
                    >
                      {item}
                    </motion.span>
                  ))}
                </div>
              </div>
            );
          })}
        </div>

        {/* Experience section */}
        <div className="reveal" style={{ marginTop: 80 }}>
          <h3 style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(28px, 4vw, 42px)',
            marginBottom: 32,
          }}>
            Experience & <span className="gradient-text">Engagement</span>
          </h3>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              {
                role: 'Media Manager',
                org: 'ENISo Auto-Crew & ACM ENISo',
                period: 'Dec 2025 → Present',
                desc: 'Full management of the club\'s visual and digital identity.',
                color: '#8b5cf6',
                icon: '🎨',
              },
              {
                role: 'Seasonal Agent',
                org: 'La Poste Tunisienne',
                period: 'Jun 2024 → Aug 2024',
                desc: 'Customer operations management in a high-volume institutional environment. Professional communication and stress management skills. Official attestation obtained.',
                color: '#06b6d4',
                icon: '📮',
              },
            ].map(e => (
              <div key={e.role} style={{
                display: 'flex',
                gap: 24,
                padding: '24px 28px',
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: 16,
                transition: 'border-color 0.2s',
                alignItems: 'flex-start',
              }}
                onMouseEnter={el => el.currentTarget.style.borderColor = e.color}
                onMouseLeave={el => el.currentTarget.style.borderColor = 'var(--border)'}
              >
                <div style={{
                  width: 44,
                  height: 44,
                  borderRadius: 10,
                  background: `${e.color}20`,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  fontSize: '1.3rem',
                  flexShrink: 0,
                  border: `1px solid ${e.color}30`,
                }}>
                  {e.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', flexWrap: 'wrap', gap: 8, marginBottom: 4 }}>
                    <div>
                      <span style={{ fontWeight: 600, fontSize: '1rem' }}>{e.role}</span>
                      <span style={{ color: 'var(--muted)', fontSize: '0.85rem' }}> · {e.org}</span>
                    </div>
                    <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.72rem', color: e.color }}>{e.period}</span>
                  </div>
                  <p style={{ color: 'var(--muted)', fontSize: '0.88rem', lineHeight: 1.7 }}>{e.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
