import { useEffect, useRef } from 'react';
import { motion } from 'framer-motion';

const stats = [
  { value: '5+', label: 'Projects Built' },
  { value: '22K', label: 'LinkedIn Impressions' },
  { value: '90%', label: 'ML Model Accuracy' },
  { value: '3', label: 'Languages Spoken' },
];

export default function About() {
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting) {
            e.target.querySelectorAll('.reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 120);
            });
          }
        });
      },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section id="about" ref={sectionRef} style={{ padding: 'clamp(80px, 10vw, 140px) clamp(24px, 5vw, 80px)' }}>
      {/* Section label */}
      <div className="reveal" style={{
        display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24,
      }}>
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', letterSpacing: '0.3em', color: 'var(--violet)', textTransform: 'uppercase' }}>
          00. About
        </span>
        <div style={{ flex: 1, height: 1, background: 'var(--border)', maxWidth: 80 }} />
      </div>

      <div style={{
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 80,
        alignItems: 'start',
        maxWidth: 1200,
        margin: '0 auto',
      }}
        className="about-grid"
      >
        {/* Left */}
        <div>
          <h2 className="reveal" style={{
            fontFamily: 'var(--font-display)',
            fontSize: 'clamp(42px, 6vw, 72px)',
            lineHeight: 0.95,
            letterSpacing: '-0.01em',
            marginBottom: 32,
          }}>
            Building AI <br />
            <span className="gradient-text">Systems</span> that<br />
            actually work
          </h2>

          <p className="reveal" style={{
            color: 'var(--muted)',
            lineHeight: 1.9,
            fontSize: '1.05rem',
            marginBottom: 24,
          }}>
            I'm Issra Mrabet, a 1st-year Applied Computer Engineering student at ENISo (École Nationale d'Ingénieurs de Sousse), Tunisia. I came through the Math-Physics preparatory cycle at IPEIM, Monastir — two years of building the foundations to then break them with code.
          </p>

          <p className="reveal" style={{
            color: 'var(--muted)',
            lineHeight: 1.9,
            fontSize: '1.05rem',
            marginBottom: 40,
          }}>
            I'm obsessed with the intersection of AI and real-world impact — from gesture-controlled interfaces to medical imaging diagnostics. I build things that see, think, and respond. Currently seeking a summer internship to contribute to production-level projects.
          </p>

          {/* Education */}
          <div className="reveal" style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            {[
              {
                school: 'ENISo',
                degree: 'Applied Computer Engineering',
                period: 'Sep 2025 → Present',
                icon: '🏛️',
              },
              {
                school: 'IPEIM',
                degree: 'Preparatory Cycle — Math & Physics',
                period: 'Sep 2023 → Jun 2025',
                icon: '📐',
              },
            ].map(e => (
              <div key={e.school} style={{
                display: 'flex',
                gap: 16,
                padding: '18px 24px',
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: 12,
                transition: 'border-color 0.2s ease',
              }}
                onMouseEnter={el => el.currentTarget.style.borderColor = 'var(--violet)'}
                onMouseLeave={el => el.currentTarget.style.borderColor = 'var(--border)'}
              >
                <span style={{ fontSize: '1.4rem' }}>{e.icon}</span>
                <div>
                  <div style={{ fontWeight: 600, marginBottom: 2 }}>{e.school}</div>
                  <div style={{ color: 'var(--muted)', fontSize: '0.85rem' }}>{e.degree}</div>
                  <div style={{ color: 'var(--violet)', fontSize: '0.75rem', fontFamily: 'var(--font-mono)', marginTop: 4 }}>{e.period}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right - Stats */}
        <div>
          {/* Stats grid */}
          <div className="reveal" style={{
            display: 'grid',
            gridTemplateColumns: '1fr 1fr',
            gap: 16,
            marginBottom: 40,
          }}>
            {stats.map(s => (
              <div key={s.label} style={{
                padding: '32px 24px',
                background: 'var(--surface)',
                border: '1px solid var(--border)',
                borderRadius: 16,
                textAlign: 'center',
                transition: 'all 0.3s ease',
              }}
                onMouseEnter={el => { el.currentTarget.style.borderColor = 'var(--cyan)'; el.currentTarget.style.transform = 'translateY(-4px)'; }}
                onMouseLeave={el => { el.currentTarget.style.borderColor = 'var(--border)'; el.currentTarget.style.transform = 'translateY(0)'; }}
              >
                <div style={{
                  fontFamily: 'var(--font-display)',
                  fontSize: 'clamp(36px, 4vw, 54px)',
                  lineHeight: 1,
                  background: 'linear-gradient(135deg, var(--violet), var(--cyan))',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                  marginBottom: 8,
                }}>
                  {s.value}
                </div>
                <div style={{ color: 'var(--muted)', fontSize: '0.8rem', fontFamily: 'var(--font-mono)', letterSpacing: '0.1em' }}>
                  {s.label}
                </div>
              </div>
            ))}
          </div>

          {/* Languages */}
          <div className="reveal" style={{
            padding: '28px',
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            borderRadius: 16,
            marginBottom: 24,
          }}>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.7rem', letterSpacing: '0.2em', color: 'var(--violet)', marginBottom: 20, textTransform: 'uppercase' }}>
              Languages
            </div>
            {[
              { lang: 'Arabic', level: 'Native', pct: 100 },
              { lang: 'French', level: 'C1 Fluent', pct: 90 },
              { lang: 'English', level: 'C1 Professional', pct: 88 },
            ].map(l => (
              <div key={l.lang} style={{ marginBottom: 16 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
                  <span style={{ fontSize: '0.9rem' }}>{l.lang}</span>
                  <span style={{ fontSize: '0.75rem', fontFamily: 'var(--font-mono)', color: 'var(--muted)' }}>{l.level}</span>
                </div>
                <div style={{ height: 3, background: 'var(--surface-2)', borderRadius: 3, overflow: 'hidden' }}>
                  <motion.div
                    initial={{ width: 0 }}
                    whileInView={{ width: `${l.pct}%` }}
                    viewport={{ once: true }}
                    transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
                    style={{
                      height: '100%',
                      background: 'linear-gradient(90deg, var(--violet), var(--cyan))',
                      borderRadius: 3,
                    }}
                  />
                </div>
              </div>
            ))}
          </div>

          {/* Interests */}
          <div className="reveal" style={{ display: 'flex', flexWrap: 'wrap', gap: 8 }}>
            {['Artificial Intelligence', 'Computer Vision', 'Full-Stack Dev', 'Competitive Programming', 'Media Design'].map(i => (
              <span key={i} className="skill-tag">{i}</span>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @media (max-width: 768px) {
          .about-grid { grid-template-columns: 1fr !important; gap: 48px !important; }
        }
      `}</style>
    </section>
  );
}
