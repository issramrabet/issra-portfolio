import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import Particles from '@tsparticles/react';
import { loadSlim } from '@tsparticles/slim';

const roles = [
  'AI Engineer',
  'Computer Vision Dev',
  'Deep Learning Builder',
  'Full-Stack Maker',
  'Hackathon Champion',
];

function TypeWriter({ words }) {
  const [index, setIndex] = useState(0);
  const [displayed, setDisplayed] = useState('');
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    const current = words[index];
    let timeout;
    if (!deleting && displayed.length < current.length) {
      timeout = setTimeout(() => setDisplayed(current.slice(0, displayed.length + 1)), 80);
    } else if (!deleting && displayed.length === current.length) {
      timeout = setTimeout(() => setDeleting(true), 2000);
    } else if (deleting && displayed.length > 0) {
      timeout = setTimeout(() => setDisplayed(displayed.slice(0, -1)), 40);
    } else if (deleting && displayed.length === 0) {
      setDeleting(false);
      setIndex((index + 1) % words.length);
    }
    return () => clearTimeout(timeout);
  }, [displayed, deleting, index, words]);

  return (
    <span style={{ color: 'var(--cyan)', fontFamily: 'var(--font-mono)' }}>
      {displayed}
      <span className="type-cursor" />
    </span>
  );
}

export default function Hero() {
  const particlesInit = async (engine) => {
    await loadSlim(engine);
  };

  return (
    <section
      id="home"
      className="grid-bg"
      style={{
        minHeight: '100vh',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        position: 'relative',
        padding: '120px 40px 60px',
      }}
    >
      {/* Particles */}
      <div style={{ position: 'absolute', inset: 0, zIndex: 0 }}>
        <Particles
          id="tsparticles"
          init={particlesInit}
          options={{
            background: { color: { value: 'transparent' } },
            fpsLimit: 60,
            particles: {
              color: { value: ['#8b5cf6', '#06b6d4', '#ec4899'] },
              links: {
                enable: true,
                color: '#8b5cf6',
                distance: 120,
                opacity: 0.15,
                width: 1,
              },
              move: {
                enable: true,
                speed: 0.6,
                random: true,
                outModes: 'bounce',
              },
              number: { value: 60, density: { enable: true, area: 900 } },
              opacity: { value: { min: 0.1, max: 0.5 } },
              size: { value: { min: 1, max: 3 } },
            },
            interactivity: {
              events: {
                onHover: { enable: true, mode: 'repulse' },
                onClick: { enable: true, mode: 'push' },
              },
              modes: {
                repulse: { distance: 100, duration: 0.4 },
                push: { quantity: 4 },
              },
            },
            detectRetina: true,
          }}
        />
      </div>

      {/* Glowing orbs */}
      <div style={{
        position: 'absolute',
        top: '20%',
        left: '10%',
        width: 400,
        height: 400,
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(139,92,246,0.12) 0%, transparent 70%)',
        filter: 'blur(40px)',
        pointerEvents: 'none',
        zIndex: 0,
      }} />
      <div style={{
        position: 'absolute',
        bottom: '15%',
        right: '8%',
        width: 350,
        height: 350,
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(6,182,212,0.1) 0%, transparent 70%)',
        filter: 'blur(40px)',
        pointerEvents: 'none',
        zIndex: 0,
      }} />

      {/* Content */}
      <div style={{
        position: 'relative',
        zIndex: 1,
        maxWidth: 1200,
        width: '100%',
        display: 'grid',
        gridTemplateColumns: '1fr 1fr',
        gap: 60,
        alignItems: 'center',
      }}
        className="hero-grid"
      >
        {/* Left - Text */}
        <div>
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.8rem',
              letterSpacing: '0.3em',
              textTransform: 'uppercase',
              color: 'var(--violet)',
              marginBottom: 16,
            }}
          >
            ✦ Available for Internship
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
            style={{
              fontFamily: 'var(--font-display)',
              fontSize: 'clamp(60px, 8vw, 110px)',
              lineHeight: 0.92,
              letterSpacing: '-0.01em',
              marginBottom: 24,
            }}
          >
            <div className="glitch-wrapper" data-text="ISSRA">ISSRA</div>
            <br />
            <div style={{ color: 'var(--muted)' }} className="glitch-wrapper" data-text="MRABET">MRABET</div>
          </motion.h1>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.6, duration: 0.7 }}
            style={{
              fontSize: 'clamp(1rem, 2vw, 1.25rem)',
              marginBottom: 32,
              lineHeight: 1.6,
            }}
          >
            <TypeWriter words={roles} />
          </motion.div>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.8, duration: 0.7 }}
            style={{
              color: 'var(--muted)',
              fontSize: '1rem',
              lineHeight: 1.8,
              maxWidth: 480,
              marginBottom: 40,
            }}
          >
            1st-year Engineering student at ENISo, Sousse. Building AI systems that see, understand, and act — from medical imaging to gesture control.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 1, duration: 0.7 }}
            style={{ display: 'flex', gap: 16, flexWrap: 'wrap', alignItems: 'center' }}
          >
            <button
              onClick={() => document.getElementById('projects').scrollIntoView({ behavior: 'smooth' })}
              style={{
                padding: '14px 32px',
                borderRadius: 100,
                background: 'linear-gradient(135deg, var(--violet), var(--cyan))',
                border: 'none',
                color: '#fff',
                fontFamily: 'var(--font-mono)',
                fontSize: '0.8rem',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
                cursor: 'pointer',
                boxShadow: '0 0 30px var(--violet-glow)',
                transition: 'transform 0.2s ease, box-shadow 0.2s ease',
              }}
              onMouseEnter={e => { e.target.style.transform = 'scale(1.05)'; e.target.style.boxShadow = '0 0 50px var(--violet-glow)'; }}
              onMouseLeave={e => { e.target.style.transform = 'scale(1)'; e.target.style.boxShadow = '0 0 30px var(--violet-glow)'; }}
            >
              View Projects →
            </button>

            <a
              href="/cv_issra.pdf"
              download
              style={{
                padding: '14px 32px',
                borderRadius: 100,
                background: 'transparent',
                border: '1px solid var(--border)',
                color: 'var(--muted)',
                fontFamily: 'var(--font-mono)',
                fontSize: '0.8rem',
                letterSpacing: '0.15em',
                textTransform: 'uppercase',
                cursor: 'pointer',
                textDecoration: 'none',
                transition: 'all 0.2s ease',
              }}
              onMouseEnter={e => { e.target.style.borderColor = 'var(--violet)'; e.target.style.color = 'var(--white)'; }}
              onMouseLeave={e => { e.target.style.borderColor = 'var(--border)'; e.target.style.color = 'var(--muted)'; }}
            >
              Download CV ↓
            </a>
          </motion.div>

          {/* Social icons */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.2, duration: 0.7 }}
            style={{ display: 'flex', gap: 20, marginTop: 40 }}
          >
            {[
              { icon: '⬡', label: 'GitHub', url: 'https://github.com/IssraMrabet', color: 'var(--white)' },
              { icon: '⬡', label: 'LinkedIn', url: 'https://linkedin.com/in/issra-mrabet', color: '#0077B5' },
              { icon: '⬡', label: 'Instagram', url: 'https://instagram.com/', color: '#E1306C' },
            ].map(s => (
              <a key={s.label} href={s.url} target="_blank" rel="noopener noreferrer"
                style={{
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.72rem',
                  letterSpacing: '0.15em',
                  color: 'var(--muted)',
                  textDecoration: 'none',
                  textTransform: 'uppercase',
                  transition: 'color 0.2s ease',
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6,
                }}
                onMouseEnter={e => e.currentTarget.style.color = s.color}
                onMouseLeave={e => e.currentTarget.style.color = 'var(--muted)'}
              >
                <span style={{ fontSize: '0.6rem' }}>◆</span> {s.label}
              </a>
            ))}
          </motion.div>
        </div>

        {/* Right - Photo */}
        <motion.div
          initial={{ opacity: 0, scale: 0.8, x: 60 }}
          animate={{ opacity: 1, scale: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 1, ease: [0.16, 1, 0.3, 1] }}
          style={{ display: 'flex', justifyContent: 'center', position: 'relative' }}
        >
          {/* Glow behind photo */}
          <div style={{
            position: 'absolute',
            width: '80%',
            height: '80%',
            borderRadius: '50%',
            background: 'radial-gradient(circle, rgba(139,92,246,0.2) 0%, transparent 70%)',
            filter: 'blur(60px)',
            top: '10%',
            left: '10%',
          }} />
          
          {/* Photo container */}
          <div className="animated-border-wrap" style={{
            width: 'clamp(260px, 35vw, 420px)',
            height: 'clamp(260px, 35vw, 420px)',
            position: 'relative',
          }}>
            <div style={{
              width: '100%',
              height: '100%',
              borderRadius: '50%',
              overflow: 'hidden',
              background: 'var(--surface)',
              border: '2px solid var(--bg)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              position: 'relative',
            }}>
              {/* Replace with your photo */}
              <img
                src="/issra.png"
                alt="Issra Mrabet"
                style={{
                  width: '100%',
                  height: '100%',
                  objectFit: 'cover',
                  objectPosition: 'top center',
                }}
                onError={(e) => {
                  // Fallback if no image yet
                  e.target.style.display = 'none';
                  e.target.parentNode.innerHTML += `<div style="font-family:var(--font-display);font-size:clamp(80px,12vw,120px);color:var(--violet);opacity:0.6">IM</div>`;
                }}
              />
            </div>
          </div>

          {/* Floating badges */}
          <motion.div
            animate={{ y: [-6, 6, -6] }}
            transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
            style={{
              position: 'absolute',
              top: '8%',
              right: '-5%',
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: 12,
              padding: '10px 16px',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.72rem',
              color: 'var(--cyan)',
              whiteSpace: 'nowrap',
              boxShadow: '0 8px 32px rgba(6,182,212,0.1)',
            }}
          >
            🏆 Hackathon Winner
          </motion.div>

          <motion.div
            animate={{ y: [6, -6, 6] }}
            transition={{ repeat: Infinity, duration: 3.5, ease: 'easeInOut' }}
            style={{
              position: 'absolute',
              bottom: '12%',
              left: '-8%',
              background: 'var(--surface)',
              border: '1px solid var(--border)',
              borderRadius: 12,
              padding: '10px 16px',
              fontFamily: 'var(--font-mono)',
              fontSize: '0.72rem',
              color: 'var(--violet)',
              whiteSpace: 'nowrap',
              boxShadow: '0 8px 32px rgba(139,92,246,0.1)',
            }}
          >
            🔥 22K LinkedIn Impressions
          </motion.div>
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        style={{
          position: 'absolute',
          bottom: 40,
          left: '50%',
          transform: 'translateX(-50%)',
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
          gap: 8,
        }}
      >
        <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.65rem', color: 'var(--muted)', letterSpacing: '0.2em' }}>SCROLL</span>
        <motion.div
          animate={{ y: [0, 8, 0] }}
          transition={{ repeat: Infinity, duration: 1.5 }}
          style={{ width: 1, height: 40, background: 'linear-gradient(180deg, var(--violet), transparent)' }}
        />
      </motion.div>

      <style>{`
        @media (max-width: 768px) {
          .hero-grid {
            grid-template-columns: 1fr !important;
            text-align: center;
          }
          .hero-grid > div:last-child {
            order: -1;
          }
        }
      `}</style>
    </section>
  );
}
