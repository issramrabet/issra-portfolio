import { useState, useEffect } from 'react';
import Cursor from './components/Cursor';
import Preloader from './components/Preloader';
import Navbar from './components/Navbar';
import Hero from './components/Hero';
import About from './components/About';
import Projects from './components/Projects';
import Skills from './components/Skills';
import Contact from './components/Contact';
import Footer from './components/Footer';

export default function App() {
  const [loading, setLoading] = useState(true);

  // Lenis smooth scroll
  useEffect(() => {
    let lenis;
    if (!loading) {
      import('lenis').then(({ default: Lenis }) => {
        lenis = new Lenis({
          duration: 1.4,
          easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
          smooth: true,
        });
        function raf(time) {
          lenis.raf(time);
          requestAnimationFrame(raf);
        }
        requestAnimationFrame(raf);
      });
    }
    return () => { if (lenis) lenis.destroy(); };
  }, [loading]);

  return (
    <>
      <Cursor />
      <Preloader onDone={() => setLoading(false)} />

      {!loading && (
        <>
          {/* Scan line decoration */}
          <div className="scanline" />

          <Navbar />

          <main>
            <Hero />
            <About />
            <Projects />
            <Skills />
            <Contact />
          </main>

          <Footer />
        </>
      )}
    </>
  );
}
