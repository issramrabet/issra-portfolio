import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

const links = ['Home', 'About', 'Projects', 'Skills', 'Contact'];

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const scrollTo = (id) => {
    const el = document.getElementById(id.toLowerCase());
    if (el) el.scrollIntoView({ behavior: 'smooth' });
    setOpen(false);
  };

  return (
    <>
      <motion.nav
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        style={{
          position: 'fixed',
          top: 0,
          left: 0,
          right: 0,
          zIndex: 1000,
          padding: '0 40px',
          height: 70,
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'space-between',
          backdropFilter: scrolled ? 'blur(20px)' : 'none',
          background: scrolled ? 'rgba(4,4,15,0.85)' : 'transparent',
          borderBottom: scrolled ? '1px solid var(--border)' : 'none',
          transition: 'all 0.4s ease',
        }}
      >
        {/* Logo */}
        <div
          onClick={() => scrollTo('home')}
          style={{
            fontFamily: 'var(--font-display)',
            fontSize: '1.8rem',
            letterSpacing: '0.05em',
            cursor: 'pointer',
            background: 'linear-gradient(135deg, var(--violet), var(--cyan))',
            WebkitBackgroundClip: 'text',
            WebkitTextFillColor: 'transparent',
          }}
        >
          IM
        </div>

        {/* Desktop links */}
        <div style={{ display: 'flex', gap: 40, alignItems: 'center' }}
          className="hidden md:flex">
          {links.map(l => (
            <button key={l} className="nav-link" onClick={() => scrollTo(l)} style={{
              background: 'none', border: 'none', cursor: 'pointer',
            }}>
              {l}
            </button>
          ))}
          <a
            href="/cv_issra.pdf"
            download
            style={{
              fontFamily: 'var(--font-mono)',
              fontSize: '0.75rem',
              letterSpacing: '0.15em',
              textTransform: 'uppercase',
              padding: '8px 20px',
              border: '1px solid var(--violet)',
              borderRadius: 100,
              color: 'var(--violet)',
              textDecoration: 'none',
              transition: 'all 0.25s ease',
            }}
            onMouseEnter={e => {
              e.target.style.background = 'var(--violet)';
              e.target.style.color = '#fff';
            }}
            onMouseLeave={e => {
              e.target.style.background = 'transparent';
              e.target.style.color = 'var(--violet)';
            }}
          >
            Resume ↓
          </a>
        </div>

        {/* Mobile hamburger */}
        <button
          onClick={() => setOpen(!open)}
          style={{ background: 'none', border: 'none', cursor: 'pointer', display: 'none' }}
          className="block md:hidden"
        >
          <div style={{ width: 24, height: 2, background: 'var(--white)', marginBottom: 5, transition: 'all 0.3s', transform: open ? 'rotate(45deg) translateY(7px)' : 'none' }} />
          <div style={{ width: 24, height: 2, background: 'var(--white)', marginBottom: 5, opacity: open ? 0 : 1 }} />
          <div style={{ width: 24, height: 2, background: 'var(--white)', transition: 'all 0.3s', transform: open ? 'rotate(-45deg) translateY(-7px)' : 'none' }} />
        </button>
      </motion.nav>

      {/* Mobile menu */}
      {open && (
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          style={{
            position: 'fixed',
            top: 70,
            left: 0,
            right: 0,
            background: 'rgba(4,4,15,0.97)',
            backdropFilter: 'blur(20px)',
            zIndex: 999,
            padding: '32px 40px',
            display: 'flex',
            flexDirection: 'column',
            gap: 24,
            borderBottom: '1px solid var(--border)',
          }}
        >
          {links.map(l => (
            <button key={l} className="nav-link" onClick={() => scrollTo(l)} style={{
              background: 'none', border: 'none', cursor: 'pointer', textAlign: 'left',
              fontSize: '1.1rem',
            }}>
              {l}
            </button>
          ))}
        </motion.div>
      )}
    </>
  );
}
