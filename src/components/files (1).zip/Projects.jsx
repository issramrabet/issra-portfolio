import { useState, useRef, useEffect } from 'react';
import { motion } from 'framer-motion';
import { projects } from '../data/projects';
import ProjectModal from './ProjectModal';

export default function Projects() {
  const [selected, setSelected] = useState(null);
  const sectionRef = useRef(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      (entries) => {
        entries.forEach(e => {
          if (e.isIntersecting) {
            e.target.querySelectorAll('.reveal').forEach((el, i) => {
              setTimeout(() => el.classList.add('visible'), i * 100);
            });
          }
        });
      },
      { threshold: 0.05 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="projects"
      ref={sectionRef}
      style={{ padding: 'clamp(80px, 10vw, 140px) clamp(24px, 5vw, 80px)', background: 'var(--bg-2)' }}
    >
      <div style={{ maxWidth: 1200, margin: '0 auto' }}>
        {/* Label */}
        <div className="reveal" style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 24 }}>
          <span style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', letterSpacing: '0.3em', color: 'var(--violet)', textTransform: 'uppercase' }}>
            01. Projects
          </span>
          <div style={{ flex: 1, height: 1, background: 'var(--border)', maxWidth: 80 }} />
        </div>

        <h2 className="reveal" style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'clamp(42px, 6vw, 72px)',
          lineHeight: 0.95,
          letterSpacing: '-0.01em',
          marginBottom: 16,
        }}>
          Things I've <span className="gradient-text">Built</span>
        </h2>

        <p className="reveal" style={{ color: 'var(--muted)', fontSize: '1rem', marginBottom: 64, maxWidth: 560 }}>
          Click any project to explore it — tech stack, description, and GitHub link.
        </p>

        {/* Grid */}
        <div style={{
          display: 'grid',
          gridTemplateColumns: 'repeat(auto-fill, minmax(340px, 1fr))',
          gap: 24,
        }}>
          {projects.map((project, i) => (
            <motion.div
              key={project.id}
              className="project-card reveal"
              onClick={() => setSelected(project)}
              whileHover={{ y: -8 }}
              transition={{ type: 'spring', stiffness: 300, damping: 20 }}
              style={{ padding: '32px', position: 'relative', overflow: 'hidden' }}
            >
              {/* Color glow top */}
              <div style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: 2,
                background: `linear-gradient(90deg, transparent, ${project.color}, transparent)`,
              }} />

              {/* Icon */}
              <div style={{
                width: 52,
                height: 52,
                borderRadius: 12,
                background: project.glow,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.6rem',
                marginBottom: 20,
                border: `1px solid ${project.color}30`,
              }}>
                {project.icon}
              </div>

              {/* Badge */}
              {project.badge && (
                <div style={{
                  display: 'inline-block',
                  padding: '3px 10px',
                  borderRadius: 100,
                  background: `${project.color}15`,
                  border: `1px solid ${project.color}40`,
                  color: project.color,
                  fontFamily: 'var(--font-mono)',
                  fontSize: '0.65rem',
                  letterSpacing: '0.08em',
                  marginBottom: 12,
                }}>
                  {project.badge}
                </div>
              )}

              <h3 style={{
                fontFamily: 'var(--font-display)',
                fontSize: '1.8rem',
                letterSpacing: '0.03em',
                marginBottom: 4,
                color: project.color,
              }}>
                {project.title}
              </h3>

              <p style={{
                color: 'var(--muted)',
                fontSize: '0.85rem',
                fontFamily: 'var(--font-mono)',
                marginBottom: 16,
              }}>
                {project.subtitle}
              </p>

              <p style={{
                color: 'var(--muted)',
                fontSize: '0.9rem',
                lineHeight: 1.7,
                marginBottom: 24,
                display: '-webkit-box',
                WebkitLineClamp: 3,
                WebkitBoxOrient: 'vertical',
                overflow: 'hidden',
              }}>
                {project.description}
              </p>

              {/* Tech tags */}
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, marginBottom: 24 }}>
                {project.tech.slice(0, 3).map(t => (
                  <span key={t} style={{
                    padding: '3px 10px',
                    borderRadius: 100,
                    background: 'var(--surface-2)',
                    border: '1px solid var(--border)',
                    color: 'var(--muted)',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.68rem',
                  }}>
                    {t}
                  </span>
                ))}
                {project.tech.length > 3 && (
                  <span style={{
                    padding: '3px 10px',
                    borderRadius: 100,
                    background: 'var(--surface-2)',
                    border: '1px solid var(--border)',
                    color: 'var(--muted)',
                    fontFamily: 'var(--font-mono)',
                    fontSize: '0.68rem',
                  }}>
                    +{project.tech.length - 3}
                  </span>
                )}
              </div>

              {/* Click hint */}
              <div style={{
                display: 'flex',
                alignItems: 'center',
                gap: 8,
                color: project.color,
                fontFamily: 'var(--font-mono)',
                fontSize: '0.72rem',
                letterSpacing: '0.1em',
                opacity: 0.8,
              }}>
                <span>Open Case Study</span>
                <span>→</span>
              </div>
            </motion.div>
          ))}

          {/* Add More Placeholder */}
          <div style={{
            padding: '32px',
            border: '1px dashed var(--border)',
            borderRadius: 16,
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'center',
            justifyContent: 'center',
            gap: 12,
            minHeight: 280,
            opacity: 0.4,
            transition: 'opacity 0.2s',
          }}
            onMouseEnter={e => e.currentTarget.style.opacity = '0.7'}
            onMouseLeave={e => e.currentTarget.style.opacity = '0.4'}
          >
            <div style={{ fontSize: '2rem' }}>＋</div>
            <div style={{ fontFamily: 'var(--font-mono)', fontSize: '0.75rem', letterSpacing: '0.1em', color: 'var(--muted)', textAlign: 'center' }}>
              More projects<br />coming soon
            </div>
          </div>
        </div>
      </div>

      {selected && (
        <ProjectModal project={selected} onClose={() => setSelected(null)} />
      )}
    </section>
  );
}
